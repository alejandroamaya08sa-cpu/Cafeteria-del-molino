"""Step 3 – Unsupervised mining: clustering.

A) Products: group the 29 menu items by *when / how* they sell (K-Means, validated with
   silhouette, Davies–Bouldin, Calinski–Harabasz; compared with Ward hierarchical clustering).
B) Days: group operating days by their demand profile (K-Means).

Writes reports/figures/fig_clust_*.png, reports/tables/clust_*.csv, reports/tables/clust_stats.json
Usage:  python src/clustering.py
"""
from __future__ import annotations

import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats
from scipy.cluster.hierarchy import fcluster, linkage
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import (adjusted_rand_score, calinski_harabasz_score,
                             davies_bouldin_score, silhouette_score)
from sklearn.preprocessing import StandardScaler

from config import DATA_PROC, DAYPART_ORDER, SEED, TAB_DIR
from mining_utils import PALETTE, save_table, savefig, set_style


def select_k(X: np.ndarray, kmax: int = 8) -> pd.DataFrame:
    rows = []
    for k in range(2, kmax + 1):
        km = KMeans(n_clusters=k, n_init=25, random_state=SEED).fit(X)
        rows.append({"k": k, "inertia": km.inertia_, "silhouette": silhouette_score(X, km.labels_),
                     "davies_bouldin": davies_bouldin_score(X, km.labels_),
                     "calinski_harabasz": calinski_harabasz_score(X, km.labels_)})
    return pd.DataFrame(rows)


def stability(X: np.ndarray, k: int, labels: np.ndarray, runs: int = 40) -> float:
    """Mean ARI between the reference partition and K-Means re-fits on bootstrap samples."""
    rng = np.random.default_rng(SEED)
    aris = []
    for r in range(runs):
        idx = rng.choice(len(X), len(X), replace=True)
        km = KMeans(n_clusters=k, n_init=10, random_state=r).fit(X[idx])
        aris.append(adjusted_rand_score(labels, km.predict(X)))
    return float(np.mean(aris))


def main() -> None:
    set_style()
    S = pd.read_csv(DATA_PROC / "sales_clean.csv", parse_dates=["timestamp", "date"])
    out: dict = {}

    # =========================== A) PRODUCT CLUSTERING ===========================
    units = S.groupby("product")["quantity"].sum()
    dp = S.pivot_table(index="product", columns="daypart", values="quantity", aggfunc="sum", fill_value=0)[DAYPART_ORDER]
    dp = dp.div(dp.sum(axis=1), axis=0).add_prefix("share_")
    wk = S.groupby("product").apply(lambda g: g.loc[g.is_weekend, "quantity"].sum() / g["quantity"].sum(), include_groups=False).rename("share_weekend")
    n_days = S["date"].nunique()
    price = S.groupby("product")["unit_price"].median().rename("median_price")
    upd = (units / n_days).rename("units_per_day")
    daily_units = S.pivot_table(index="date", columns="product", values="quantity", aggfunc="sum", fill_value=0)
    temp = S.groupby("date")["temperature_2m_mean"].first().reindex(daily_units.index)
    temp_rho = daily_units.apply(lambda c: stats.spearmanr(c, temp)[0]).rename("temp_sensitivity")
    basket = S.groupby("order_id")["product"].nunique().rename("basket_size")
    attach = (S.merge(basket, on="order_id").groupby("product")["basket_size"].mean() - 1).rename("avg_companions")
    F = pd.concat([dp, wk, price, upd, temp_rho, attach], axis=1)
    F["median_price"] = np.log(F["median_price"]); F["units_per_day"] = np.log(F["units_per_day"])
    F = F.rename(columns={"median_price": "log_price", "units_per_day": "log_units_day"})
    Z = StandardScaler().fit_transform(F)

    ks = select_k(Z, kmax=8)
    save_table(ks.round(4), "clust_product_k_selection")
    k_best = int(ks.loc[ks["silhouette"].idxmax(), "k"])
    km = KMeans(n_clusters=k_best, n_init=50, random_state=SEED).fit(Z)
    F["cluster_raw"] = km.labels_
    # Ward hierarchical for comparison
    Lk = linkage(Z, method="ward")
    ward = fcluster(Lk, t=k_best, criterion="maxclust") - 1
    out["product_k_best"] = k_best
    out["product_silhouette"] = float(silhouette_score(Z, km.labels_))
    out["product_davies_bouldin"] = float(davies_bouldin_score(Z, km.labels_))
    out["product_calinski_harabasz"] = float(calinski_harabasz_score(Z, km.labels_))
    out["product_ari_kmeans_vs_ward"] = float(adjusted_rand_score(km.labels_, ward))
    out["product_bootstrap_ari"] = stability(Z, k_best, km.labels_)
    out["product_silhouette_by_k"] = {int(r.k): round(float(r.silhouette), 3) for r in ks.itertuples()}

    # name clusters after their dominant behaviour (data-driven, reviewed by hand)
    prof_raw = F.groupby("cluster_raw").mean(numeric_only=True)
    def label_cluster(row: pd.Series) -> str:
        if row["share_Morning"] > .60: return "Breakfast meals"
        if row["share_Midday"] > .40: return "Lunch & cold drinks"
        if row["share_Afternoon"] + row["share_Evening"] > .55: return "Afternoon indulgence"
        return "Core hot drinks & bakery"
    final = prof_raw.apply(label_cluster, axis=1).to_dict()
    assert len(set(final.values())) == len(final), "cluster labels must be unique - review rule thresholds"
    F["cluster"] = F["cluster_raw"].map(final)
    members = F.reset_index()[["product", "cluster"]].merge(S.drop_duplicates("product")[["product", "category"]], on="product")
    save_table(members.sort_values(["cluster", "product"]), "clust_product_members")
    prof = F.groupby("cluster").agg(n=("cluster", "size"), **{c: (c, "mean") for c in F.columns if c not in ("cluster", "cluster_raw")})
    prof["median_price_cop"] = np.exp(prof["log_price"]).round(0)
    prof["units_per_day"] = np.exp(prof["log_units_day"]).round(1)
    save_table(prof.round(3).reset_index(), "clust_product_profiles")
    out["product_clusters"] = {c: sorted(g.index.tolist()) for c, g in F.groupby("cluster")}

    pca = PCA(n_components=2, random_state=SEED).fit(Z); P = pca.transform(Z)
    out["product_pca_var_explained"] = [float(v) for v in pca.explained_variance_ratio_]

    fig, ax = plt.subplots(2, 2, figsize=(7.2, 5.8))
    a = ax[0, 0]
    a.plot(ks["k"], ks["silhouette"], marker="o", color=PALETTE[2], label="Silhouette")
    a.axvline(k_best, ls="--", color="gray", lw=.8)
    a.set_xlabel("k"); a.set_ylabel("Silhouette", color=PALETTE[2]); a.set_title("(a) Choosing k")
    b = a.twinx(); b.plot(ks["k"], ks["inertia"], marker="s", ms=3, color=PALETTE[0], label="Inertia")
    b.set_ylabel("Inertia (elbow)", color=PALETTE[0]); b.grid(False); b.spines["right"].set_visible(True)
    cl_names = sorted(F["cluster"].unique()); cmap = {c: PALETTE[i] for i, c in enumerate(cl_names)}
    mk = ["o", "s", "^", "D", "v"]
    a = ax[0, 1]
    for i, c in enumerate(cl_names):
        m = (F["cluster"] == c).values
        a.scatter(P[m, 0], P[m, 1], s=26, color=cmap[c], marker=mk[i % 5], label=c, edgecolor="white", lw=.4)
    for i, p in enumerate(F.index):
        a.annotate(p, (P[i, 0], P[i, 1]), fontsize=5, xytext=(2, 2), textcoords="offset points")
    a.set_xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.0f}% var.)"); a.set_ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.0f}% var.)")
    a.set_title("(b) K-Means clusters in PCA space"); a.legend(fontsize=5.5, loc="best")
    a = ax[1, 0]
    zprof = pd.DataFrame(StandardScaler().fit_transform(F.drop(columns=["cluster", "cluster_raw"])), index=F.index, columns=F.columns.drop(["cluster", "cluster_raw"]))
    zprof["cluster"] = F["cluster"]
    hm = zprof.groupby("cluster").mean()
    hm.columns = [c.replace("share_", "% ").replace("_", " ") for c in hm.columns]
    sns.heatmap(hm, cmap="BrBG", center=0, annot=True, fmt=".1f", annot_kws={"size": 5.5}, cbar=False, ax=a, linewidths=.3)
    a.set_title("(c) Cluster profiles (mean z-scores)"); a.set_ylabel(""); a.grid(False)
    a.tick_params(axis="x", rotation=60, labelsize=6); a.tick_params(axis="y", labelsize=6)
    a = ax[1, 1]
    from scipy.cluster.hierarchy import dendrogram
    dendrogram(Lk, labels=F.index.tolist(), orientation="right", leaf_font_size=5, ax=a, color_threshold=Lk[-(k_best - 1), 2] - 1e-9, above_threshold_color="gray")
    a.set_title(f"(d) Ward dendrogram (ARI vs K-Means = {out['product_ari_kmeans_vs_ward']:.2f})"); a.grid(False)
    savefig(fig, "fig_clust_products")

    # =========================== B) DAY CLUSTERING ===========================
    O = pd.read_csv(DATA_PROC / "orders_clean.csv", parse_dates=["timestamp", "date"])
    dd = O.groupby("date").agg(orders=("order_id", "nunique"), avg_ticket=("order_total", "mean"))
    dshare = O.pivot_table(index="date", columns="daypart", values="order_id", aggfunc="count", fill_value=0)[DAYPART_ORDER]
    dshare = dshare.div(dshare.sum(axis=1), axis=0).add_prefix("share_")
    hot = S.groupby("date").apply(lambda g: g.loc[g.is_hot_drink, "quantity"].sum() / g["quantity"].sum(), include_groups=False).rename("hot_share")
    wx = S.groupby("date").agg(temp=("temperature_2m_mean", "first"), rain=("precipitation_sum", "first"), holiday=("is_holiday", "first"), weekday=("weekday", "first"))
    G = pd.concat([dd, dshare, hot, wx], axis=1)
    G["weekend"] = (G["weekday"] >= 5).astype(int); G["holiday"] = G["holiday"].astype(int)
    feats = ["orders", "avg_ticket", "share_Morning", "share_Midday", "share_Afternoon", "share_Evening", "hot_share", "temp", "rain", "weekend"]
    Zd = StandardScaler().fit_transform(G[feats])
    ksd = select_k(Zd, 7); save_table(ksd.round(4), "clust_day_k_selection")
    kd = int(ksd.loc[ksd["silhouette"].idxmax(), "k"])
    kmd = KMeans(n_clusters=kd, n_init=50, random_state=SEED).fit(Zd)
    G["cluster"] = kmd.labels_
    out["day_k_best"] = kd; out["day_silhouette"] = float(silhouette_score(Zd, kmd.labels_))
    out["day_silhouette_by_k"] = {int(r.k): round(float(r.silhouette), 3) for r in ksd.itertuples()}
    out["day_davies_bouldin"] = float(davies_bouldin_score(Zd, kmd.labels_))
    out["day_bootstrap_ari"] = stability(Zd, kd, kmd.labels_)
    dprof = G.groupby("cluster")[feats + ["holiday"]].mean(); dprof["n_days"] = G.groupby("cluster").size()
    dprof = dprof.sort_values("orders")
    dprof.index = [f"D{i+1}" for i in range(len(dprof))]; remap = dict(zip(G.groupby("cluster")["orders"].mean().sort_values().index, dprof.index))
    G["cluster"] = G["cluster"].map(remap)
    save_table(dprof.round(3).reset_index().rename(columns={"index": "cluster"}), "clust_day_profiles")
    G.reset_index().to_csv(DATA_PROC / "daily_clusters.csv", index=False)
    out["day_profiles"] = dprof.round(2).to_dict(orient="index")
    pcad = PCA(n_components=2, random_state=SEED).fit(Zd); Pd = pcad.transform(Zd)
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.5))
    ax[0].plot(ksd["k"], ksd["silhouette"], marker="o", color=PALETTE[2]); ax[0].axvline(kd, ls="--", color="gray", lw=.8)
    ax[0].set_xlabel("k"); ax[0].set_ylabel("Silhouette"); ax[0].set_title("(a) Choosing k (days)")
    for i, c in enumerate(sorted(G["cluster"].unique())):
        m = (G["cluster"] == c).values
        ax[1].scatter(Pd[m, 0], Pd[m, 1], s=9, alpha=.7, color=PALETTE[i], marker=mk[i % 5], label=f"{c} (n={m.sum()})")
    ax[1].set_xlabel(f"PC1 ({pcad.explained_variance_ratio_[0]*100:.0f}%)"); ax[1].set_ylabel(f"PC2 ({pcad.explained_variance_ratio_[1]*100:.0f}%)")
    ax[1].set_title("(b) Day clusters (PCA)"); ax[1].legend(fontsize=5.5)
    hmd = dprof[["orders", "avg_ticket", "share_Morning", "share_Afternoon", "hot_share", "temp", "rain", "weekend"]]
    hmd = (hmd - G[hmd.columns].mean()) / G[hmd.columns].std()
    sns.heatmap(hmd, cmap="BrBG", center=0, annot=True, fmt=".1f", annot_kws={"size": 6}, cbar=False, ax=ax[2], linewidths=.3)
    ax[2].set_title("(c) Day-cluster profiles (z)"); ax[2].grid(False); ax[2].tick_params(axis="x", rotation=60)
    savefig(fig, "fig_clust_days")

    json.dump(out, open(TAB_DIR / "clust_stats.json", "w"), indent=2, default=str)
    print(json.dumps(out, indent=2, default=str))


if __name__ == "__main__":
    main()
