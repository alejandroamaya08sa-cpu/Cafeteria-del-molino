"""Small helpers shared by the pipeline scripts (plot style, saving figures/tables)."""
from __future__ import annotations

import unicodedata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from config import FIG_DIR, TAB_DIR

# Coffee-inspired palette; every series also differs in marker/hatch so that the
# figures remain readable in grayscale prints.
PALETTE = ["#6F4E37", "#C08552", "#2E6F6B", "#8F2D56", "#5B7DB1", "#A3A847", "#7A7A7A"]


def set_style() -> None:
    plt.rcParams.update({
        "figure.dpi": 110, "savefig.dpi": 220, "font.size": 8, "axes.titlesize": 8.5,
        "axes.labelsize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7, "legend.fontsize": 7,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
        "grid.alpha": .25, "grid.linewidth": .5, "axes.prop_cycle": matplotlib.cycler(color=PALETTE),
        "font.family": "DejaVu Sans", "figure.constrained_layout.use": True,
    })


def savefig(fig, name: str) -> None:
    path = FIG_DIR / f"{name}.png"
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    print(f"  figure -> {path.relative_to(FIG_DIR.parents[1])}")


def save_table(df: pd.DataFrame, name: str, index: bool = False) -> None:
    path = TAB_DIR / f"{name}.csv"
    df.to_csv(path, index=index)
    print(f"  table  -> {path.relative_to(TAB_DIR.parents[1])}")


def norm_key(s: str) -> str:
    """lower-case, accent-free, single-spaced key used to compare product names."""
    s = unicodedata.normalize("NFD", str(s))
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return " ".join(s.lower().split())
