"""Step 4 – Unsupervised mining: association rules (market-basket analysis).

FP-Growth (Han et al., 2000) on the order × product incidence matrix, then rule generation with
support, confidence, lift, leverage and conviction. Includes a sensitivity analysis on
min_support and a daypart-specific mining (Morning vs Afternoon).

Writes reports/figures/fig_rules_*.png, reports/tables/rules_*.csv, reports/tables/rules_stats.json
Usage:  python src/rules_mining.py
"""
from __future__ import annotations

import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from mlxtend.frequent_patterns import association_rules, fpgrowth

from config import DATA_PROC, TAB_DIR
from mining_utils import PALETTE, save_table, savefig, set_style

MIN_SUPPORT = 0.01      # ≥ 1 % of orders (~277 orders)
MIN_LIFT = 1.2
MIN_CONF = 0.10


def basket_matrix(S: pd.DataFrame) -> pd.DataFrame:
    return (S.assign(v=True).pivot_table(index="order_id", columns="product", values="v", aggfunc="max", fill_value=False)
            .astype(bool))


def mine(B: pd.DataFrame, min_support: float = MIN_SUPPORT, min_conf: float = MIN_CONF, min_lift: float = MIN_LIFT):
    fi = fpgrowth(B, min_support=min_support, use_colnames=True)
    if len(fi) == 0 or fi["itemsets"].map(len).max() < 2:
        return fi, pd.DataFrame()
    r = association_rules(fi, metric="confidence", min_threshold=min_conf)
    r = r[r["lift"] >= min_lift].copy()
    r["antecedent"] = r["antecedents"].map(lambda s: " + ".join(sorted(s)))
    r["consequent"] = r["consequents"].map(lambda s: " + ".join(sorted(s)))
    r["rule"] = r["antecedent"] + " → " + r["consequent"]
    return fi, r.sort_values(["lift", "confidence", "rule"], ascending=[False, False, True]).reset_index(drop=True)


def main() -> None:
    set_style()
    S = pd.read_csv(DATA_PROC / "sales_clean.csv", parse_dates=["timestamp", "date"])
    B = basket_matrix(S)
    out: dict = {"n_baskets": int(len(B)), "n_items": int(B.shape[1]),
                 "multi_item_baskets_pct": float((B.sum(axis=1) > 1).mean() * 100),
                 "avg_basket_size": float(B.sum(axis=1).mean())}

    # ---------- sensitivity on min_support
    sens = []
    for ms in [0.005, 0.01, 0.02, 0.03, 0.05]:
        fi, r = mine(B, min_support=ms)
        sens.append({"min_support": ms, "frequent_itemsets": len(fi),
                     "itemsets_size>=2": int((fi["itemsets"].map(len) >= 2).sum()),
                     "rules(lift>=1.2,conf>=.10)": len(r), "max_lift": float(r["lift"].max()) if len(r) else np.nan})
    save_table(pd.DataFrame(sens).round(3), "rules_sensitivity")

    # ---------- main mining
    fi, rules = mine(B)
    out["frequent_itemsets"] = int(len(fi)); out["rules"] = int(len(rules))
    keep = ["rule", "antecedent", "consequent", "support", "confidence", "lift", "leverage", "conviction"]
    rules = rules[keep]
    save_table(rules.round(4), "rules_all")
    # pair rules only (1 → 1) for readability
    pairs = rules[~rules["antecedent"].str.contains(r"\+") & ~rules["consequent"].str.contains(r"\+")]
    top = pairs.head(15)
    save_table(top.round(4), "rules_top15_by_lift")
    out["top_rules"] = top.round(3).to_dict(orient="records")
    out["max_lift"] = float(rules["lift"].max()); out["median_lift"] = float(rules["lift"].median())
    out["largest_itemset"] = int(fi["itemsets"].map(len).max())
    # strongest by confidence among decently frequent rules
    out["top_by_confidence"] = pairs.sort_values("confidence", ascending=False).head(5).round(3)[["rule", "support", "confidence", "lift"]].to_dict(orient="records")

    # ---------- statistical sanity check: lift>1 in all kept rules means positive association;
    # chi-square on the strongest pair
    from scipy.stats import chi2_contingency
    a_, c_ = top.iloc[0]["antecedent"], top.iloc[0]["consequent"]
    chi = chi2_contingency(pd.crosstab(B[a_], B[c_]))
    out["chi2_top_rule"] = {"rule": top.iloc[0]["rule"], "chi2": float(chi[0]), "p": float(chi[1])}

    # ---------- daypart-specific mining
    o = S.drop_duplicates("order_id").set_index("order_id")["daypart"]
    dp_tables = []
    for dp in ["Morning", "Afternoon"]:
        idx = o[o == dp].index.intersection(B.index)
        _, r = mine(B.loc[idx], min_support=0.015)
        if len(r):
            r = r[~r["antecedent"].str.contains(r"\+") & ~r["consequent"].str.contains(r"\+")].head(5)
            r = r[["rule", "support", "confidence", "lift"]].round(3); r.insert(0, "daypart", dp); dp_tables.append(r)
    if dp_tables:
        dpt = pd.concat(dp_tables); save_table(dpt, "rules_by_daypart"); out["rules_by_daypart"] = dpt.to_dict(orient="records")

    # ---------- figures
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw={"width_ratios": [1, 1.25]})
    sc = ax[0].scatter(rules["support"] * 100, rules["confidence"] * 100, c=rules["lift"], cmap="YlOrBr", edgecolor="k", lw=.3, s=22)
    plt.colorbar(sc, ax=ax[0], label="lift", shrink=.85)
    ax[0].set_xlabel("Support (% of orders)"); ax[0].set_ylabel("Confidence (%)"); ax[0].set_title(f"(a) {len(rules)} rules (supp ≥ 1 %, lift ≥ 1.2)")
    t = top.head(12).iloc[::-1]
    ax[1].barh(t["rule"], t["lift"], color=PALETTE[0])
    for i, (l, c) in enumerate(zip(t["lift"], t["confidence"])):
        ax[1].text(l + 0.03, i, f"conf {c*100:.0f}%", va="center", fontsize=5.5)
    ax[1].set_xlabel("Lift"); ax[1].set_title("(b) Top rules by lift (1→1)"); ax[1].grid(axis="y", visible=False)
    ax[1].tick_params(axis="y", labelsize=6); ax[1].set_xlim(0, t["lift"].max() * 1.25)
    savefig(fig, "fig_rules_main")

    items = sorted(set(pairs["antecedent"]) | set(pairs["consequent"]))
    L = pd.DataFrame(np.nan, index=items, columns=items)
    for r in pairs.itertuples():
        L.loc[r.antecedent, r.consequent] = r.lift
    fig, ax = plt.subplots(figsize=(3.5, 3.3))
    sns.heatmap(L, cmap="YlOrBr", ax=ax, cbar_kws={"label": "lift", "shrink": .7}, linewidths=.2, linecolor="#eee")
    ax.set_xlabel("Consequent"); ax.set_ylabel("Antecedent"); ax.set_title("Lift matrix of 1→1 rules"); ax.grid(False)
    ax.tick_params(labelsize=5)
    savefig(fig, "fig_rules_heatmap")

    json.dump(out, open(TAB_DIR / "rules_stats.json", "w"), indent=2, default=str)
    print(json.dumps({k: v for k, v in out.items() if k != "top_rules"}, indent=2, default=str))
    print(top[["rule", "support", "confidence", "lift"]].round(3).to_string())


if __name__ == "__main__":
    main()
