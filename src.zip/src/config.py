"""Shared configuration for the Cafetería del Molino data-mining module.

Everything that other scripts need (paths, seeds, business constants) lives here so
that the whole pipeline is reproducible from a single place.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "data" / "raw"
DATA_EXT = ROOT / "data" / "external"
DATA_PROC = ROOT / "data" / "processed"
FIG_DIR = ROOT / "reports" / "figures"
TAB_DIR = ROOT / "reports" / "tables"
DOCS_DIR = ROOT / "docs"

for _d in (DATA_RAW, DATA_EXT, DATA_PROC, FIG_DIR, TAB_DIR, DOCS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

SEED = 42

# --- Raw dataset (legacy cafeteria database export) ------------------------------
RAW_SALES_FILE = DATA_RAW / "ventas_raw.csv"
RAW_CATALOG_FILE = DATA_RAW / "catalogo_productos.csv"

# Mapping from the legacy (Spanish) column names to the analysis (English) names.
# If you replace the synthetic file by the real export, edit ONLY this mapping.
COLUMN_MAP = {
    "id_linea": "line_id",
    "id_pedido": "order_id",
    "fecha_hora": "timestamp",
    "mesa": "table_no",
    "canal": "channel",
    "id_empleado": "employee_id",
    "producto": "product",
    "cantidad": "quantity",
    "precio_unitario": "unit_price",
    "metodo_pago": "payment_method",
}

# --- External sources ------------------------------------------------------------
# Tunja, Boyacá (approximate city-centre coordinates)
LAT, LON = 5.5353, -73.3678
TIMEZONE = "America/Bogota"
WEATHER_FILE = DATA_EXT / "weather_tunja.csv"
HOLIDAYS_FILE = DATA_EXT / "holidays_co.csv"

# --- Business constants ----------------------------------------------------------
OPEN_HOUR, CLOSE_HOUR = 7, 20          # opening hours (inclusive start, exclusive end)
DAYPARTS = {                            # hour -> daypart label
    **{h: "Morning" for h in range(7, 11)},
    **{h: "Midday" for h in range(11, 15)},
    **{h: "Afternoon" for h in range(15, 18)},
    **{h: "Evening" for h in range(18, 21)},
}
DAYPART_ORDER = ["Morning", "Midday", "Afternoon", "Evening"]
WEEKDAY_ORDER = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
