"""Step 1 – Data audit and cleaning.

Reads  data/raw/ventas_raw.csv (+ catalogue, weather, holidays)
Writes data/processed/sales_clean.csv   (one row per order line, analysis-ready)
       data/processed/orders_clean.csv  (one row per order)
       data/processed/daily_demand.csv  (one row per day)
       reports/tables/*.csv, reports/figures/fig_cleaning.png

Every treatment is logged (rows before/after, rows affected) in
reports/tables/cleaning_log.csv so that the process is auditable and reproducible.

Usage:  python src/clean_data.py
"""
from __future__ import annotations

import difflib
import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from config import (COLUMN_MAP, DATA_EXT, DATA_PROC, DAYPARTS, HOLIDAYS_FILE, OPEN_HOUR,
                    CLOSE_HOUR, RAW_CATALOG_FILE, RAW_SALES_FILE, WEATHER_FILE, TAB_DIR)
from mining_utils import PALETTE, norm_key, save_table, savefig, set_style

LOG: list[dict] = []


def log_step(step: str, issue: str, treatment: str, affected: int, before: int, after: int) -> None:
    LOG.append({"step": step, "issue": issue, "treatment": treatment, "rows_affected": int(affected),
                "rows_before": int(before), "rows_after": int(after)})
    print(f"  [{step}] {issue}: {affected:,} affected -> {treatment} (rows {before:,} -> {after:,})")


def audit(df: pd.DataFrame, label: str) -> pd.DataFrame:
    a = pd.DataFrame({"column": df.columns, "dtype": [str(t) for t in df.dtypes],
                      "n_null": df.isna().sum().values,
                      "pct_null": (df.isna().mean().values * 100).round(2),
                      "n_unique": [df[c].nunique(dropna=True) for c in df.columns]})
    a.insert(0, "stage", label)
    return a


def parse_timestamps(s: pd.Series) -> pd.Series:
    """Two formats coexist in the legacy export: ISO and dd/mm/YYYY HH:MM."""
    iso = pd.to_datetime(s, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    alt = pd.to_datetime(s.where(iso.isna()), format="%d/%m/%Y %H:%M", errors="coerce")
    return iso.fillna(alt)


def main() -> None:
    set_style()
    print("== Loading raw data")
    raw = pd.read_csv(RAW_SALES_FILE).rename(columns=COLUMN_MAP)
    n0 = len(raw)
    print(f"  raw rows: {n0:,}  columns: {list(raw.columns)}")
    audit_before = audit(raw, "raw")
    cat = pd.read_csv(RAW_CATALOG_FILE)
    cat["key"] = cat["producto"].map(norm_key)
    cat_keys = dict(zip(cat["key"], cat["producto"]))
    product_category = dict(zip(cat["producto"], cat["categoria"]))

    # keep an untouched copy for before/after figures
    before = raw.copy()
    df = raw.copy()

    # -------------------------------------------------------------- 1. duplicates
    b = len(df)
    df = df.drop_duplicates()
    log_step("1", "Exact duplicate rows (double submission)", "drop duplicates", b - len(df), b, len(df))

    # -------------------------------------------------------------- 2. timestamps
    ts = parse_timestamps(df["timestamp"])
    n_alt = int(((~df["timestamp"].isna()) & ts.notna() &
                 df["timestamp"].astype(str).str.contains("/", regex=False)).sum())
    n_unparsed = int((df["timestamp"].notna() & ts.isna()).sum())
    bad_hours = ts.notna() & ~ts.dt.hour.between(OPEN_HOUR, CLOSE_HOUR - 1)
    ts = ts.mask(bad_hours)                                   # out-of-hours = clock error
    df["timestamp"] = ts
    log_step("2a", "Mixed timestamp formats (dd/mm/YYYY) parsed", "parse both formats", n_alt, len(df), len(df))
    log_step("2b", "Timestamps outside opening hours (clock error)", "set to missing, recover from order", int(bad_hours.sum()), len(df), len(df))
    # All lines of an order share the same timestamp: recover missing ones from sibling lines
    n_missing_ts = int(df["timestamp"].isna().sum())
    df["timestamp"] = df.groupby("order_id")["timestamp"].transform("first")
    still = int(df["timestamp"].isna().sum())
    b = len(df)
    df = df.dropna(subset=["timestamp"])
    log_step("2c", f"Missing/invalid timestamps ({n_missing_ts - still} recovered from same order)",
             "impute from order siblings; drop if impossible", still, b, len(df))

    # -------------------------------------------------------------- 3. order-level attributes
    for col in ["table_no", "channel", "employee_id", "payment_method"]:
        n_na = int(df[col].isna().sum())
        df[col] = df.groupby("order_id")[col].transform("first")
        rec = n_na - int(df[col].isna().sum())
        print(f"  [3] {col}: {n_na:,} nulls, {rec:,} recovered from same order")
    # structural null: QR orders have no waiter by design
    qr_no_emp = (df["channel"] == "QR") & df["employee_id"].isna()
    df.loc[qr_no_emp, "employee_id"] = "SELF-SERVICE"
    n_emp = int(df["employee_id"].isna().sum())
    df["employee_id"] = df["employee_id"].fillna("UNKNOWN")
    n_pay = int(df["payment_method"].isna().sum())
    df["payment_method"] = df["payment_method"].fillna("Unknown")
    log_step("3a", "Structural null: QR orders have no waiter", "label 'SELF-SERVICE'", int(qr_no_emp.sum()), len(df), len(df))
    log_step("3b", "Missing employee_id (not recoverable)", "label 'UNKNOWN'", n_emp, len(df), len(df))
    log_step("3c", "Missing payment_method (not recoverable)", "label 'Unknown'", n_pay, len(df), len(df))
    df["has_table"] = df["table_no"].notna()                  # NaN table = take-away / not recorded
    log_step("3d", "table_no missing (take-away / not recorded)", "keep NaN + boolean flag has_table",
             int((~df["has_table"]).sum()), len(df), len(df))

    # -------------------------------------------------------------- 4. product names
    b = len(df)
    n_missing_prod = int(df["product"].isna().sum())
    df = df.dropna(subset=["product"])
    log_step("4a", "Missing product name", "drop (cannot be inferred reliably)", n_missing_prod, b, len(df))
    df["product_key"] = df["product"].map(norm_key)
    exact = df["product_key"].isin(cat_keys)
    raw_variants = df.loc[df["product"] != df["product"].map(lambda x: cat_keys.get(norm_key(x), x)), "product"]
    # analyst-reviewed alias table (truncated names found by inspecting unmatched values)
    alias = {"americano": "cafe americano", "limonada": "limonada natural", "chocolate": "chocolate caliente"}
    mapped, how = [], []
    for k in df["product_key"]:
        if k in cat_keys:
            mapped.append(cat_keys[k]); how.append("normalised-exact")
        elif k in alias:
            mapped.append(cat_keys[alias[k]]); how.append("alias")
        else:
            m = difflib.get_close_matches(k, list(cat_keys), n=1, cutoff=0.84)
            mapped.append(cat_keys[m[0]] if m else np.nan); how.append("fuzzy" if m else "unmatched")
    df["product_clean"] = mapped
    df["match_type"] = how
    variants = (df.assign(changed=df["product"] != df["product_clean"])
                  .query("changed").groupby(["product", "product_clean", "match_type"]).size()
                  .reset_index(name="rows").sort_values("rows", ascending=False))
    save_table(variants, "product_name_variants")
    n_changed = int((df["product"] != df["product_clean"]).sum())
    n_unmatched = int(df["product_clean"].isna().sum())
    b = len(df)
    df = df.dropna(subset=["product_clean"])
    print("  name-resolution method counts:", df["match_type"].value_counts().to_dict())
    log_step("4b", f"Inconsistent product names ({raw['product'].nunique()} raw distinct -> {df['product_clean'].nunique()} canonical)",
             "normalise + alias + fuzzy match (difflib ≥0.84)", n_changed, b, len(df))
    if n_unmatched:
        log_step("4c", "Unmatched product names", "drop", n_unmatched, b, len(df))
    df["product"] = df["product_clean"]
    df = df.drop(columns=["product_key", "product_clean", "match_type"])
    df["category"] = df["product"].map(product_category)

    # -------------------------------------------------------------- 5. unit price
    df["unit_price"] = pd.to_numeric(df["unit_price"], errors="coerce")
    df["ym"] = df["timestamp"].dt.to_period("M")
    ref = (df[df["unit_price"] > 0].groupby(["product", "ym"])["unit_price"].median()
           .rename("ref_price").reset_index())
    df = df.merge(ref, on=["product", "ym"], how="left")
    ratio = df["unit_price"] / df["ref_price"]
    price_before = df[["unit_price", "ref_price"]].copy()
    m_na = df["unit_price"].isna()
    m_zero = df["unit_price"] <= 0
    m_scale = (ratio > 2) | ((ratio < 0.5) & ~m_zero)
    df["price_was_fixed"] = m_na | m_zero | m_scale
    df.loc[df["price_was_fixed"], "unit_price"] = df.loc[df["price_was_fixed"], "ref_price"]
    log_step("5a", "Missing unit_price", "impute product-month median (price list is deterministic)", int(m_na.sum()), len(df), len(df))
    log_step("5b", "Zero/negative unit_price", "replace by product-month median", int((m_zero & ~m_na).sum()), len(df), len(df))
    log_step("5c", "Price outliers (ratio to reference >2 or <0.5, e.g. extra zeros)", "replace by product-month median", int(m_scale.sum()), len(df), len(df))
    df = df.drop(columns=["ym"])

    # -------------------------------------------------------------- 6. quantity
    df["quantity"] = pd.to_numeric(df["quantity"], errors="coerce")
    q_pos = df.loc[df["quantity"] > 0, "quantity"]
    q_hi_ok = float(q_pos[q_pos <= 10].max())            # largest plausible quantity
    q_lo_bad = float(q_pos[q_pos > 10].min()) if (q_pos > 10).any() else float("nan")
    # Neg: sign typo -> absolute value. Extreme: the empirical distribution has a clear gap
    # (largest plausible value vs. smallest suspicious value), so >10 units in a single line is
    # treated as a typo and replaced by the product median.
    m_neg = df["quantity"] < 0
    df.loc[m_neg, "quantity"] = df.loc[m_neg, "quantity"].abs()
    m_ext = df["quantity"] > 10
    q_na = df["quantity"].isna()
    med = df[(df["quantity"] > 0) & (df["quantity"] <= 10)].groupby("product")["quantity"].median()
    fill = df["product"].map(med).fillna(1)
    df.loc[m_ext | q_na, "quantity"] = fill[m_ext | q_na]
    df["quantity"] = df["quantity"].astype(int)
    log_step("6a", "Negative quantity (sign typo)", "absolute value", int(m_neg.sum()), len(df), len(df))
    log_step("6b", f"Extreme quantity (>10; largest plausible = {q_hi_ok:.0f}, smallest suspicious = {q_lo_bad:.0f})", "replace by product median", int(m_ext.sum()), len(df), len(df))
    log_step("6c", "Missing quantity", "impute product median (mode = 1)", int(q_na.sum()), len(df), len(df))

    # -------------------------------------------------------------- 7. derived fields
    df["line_total"] = df["quantity"] * df["unit_price"]
    df["date"] = df["timestamp"].dt.normalize()
    df["hour"] = df["timestamp"].dt.hour
    df["weekday"] = df["timestamp"].dt.dayofweek
    df["weekday_name"] = df["timestamp"].dt.day_name().str[:3]
    df["month"] = df["timestamp"].dt.to_period("M").astype(str)
    df["daypart"] = df["hour"].map(DAYPARTS)
    df["is_weekend"] = df["weekday"] >= 5
    df["is_hot_drink"] = df["category"].eq("Hot drinks")

    # external features
    wx = pd.read_csv(WEATHER_FILE, parse_dates=["date"])
    hol = pd.read_csv(HOLIDAYS_FILE, parse_dates=["date"])
    df = df.merge(wx.drop(columns=["source"]), on="date", how="left")
    df["is_holiday"] = df["date"].isin(hol["date"])
    df["is_rainy"] = df["precipitation_sum"] >= 1.0
    df["weather_source"] = wx["source"].iloc[0]
    n_wx_missing = int(df["temperature_2m_mean"].isna().sum())
    log_step("7", "Join with external weather/holiday sources", f"left join on date; {n_wx_missing} lines without weather", n_wx_missing, len(df), len(df))

    # integrity checks
    assert df["line_id"].is_unique, "line_id must be unique after de-duplication"
    assert df["quantity"].min() >= 1 and df["unit_price"].min() > 0
    assert df["hour"].between(OPEN_HOUR, CLOSE_HOUR - 1).all()
    assert df["product"].isin(product_category).all()
    assert df["timestamp"].notna().all() and df["unit_price"].notna().all()
    dup_pairs = int(df.duplicated(["order_id", "product"]).sum())
    if dup_pairs:                                              # same product twice in one order -> merge
        agg = {c: "first" for c in df.columns if c not in ("quantity", "line_total")}
        agg.update({"quantity": "sum", "line_total": "sum"})
        b = len(df)
        df = df.groupby(["order_id", "product"], as_index=False).agg(agg)
        log_step("7b", "Same product repeated in one order", "merge lines (sum quantity)", dup_pairs, b, len(df))

    df = df.sort_values(["timestamp", "order_id", "line_id"]).reset_index(drop=True)
    cols = ["line_id", "order_id", "timestamp", "date", "hour", "weekday", "weekday_name", "month",
            "daypart", "is_weekend", "is_holiday", "channel", "table_no", "has_table", "employee_id",
            "payment_method", "product", "category", "is_hot_drink", "quantity", "unit_price",
            "line_total", "price_was_fixed", "temperature_2m_mean", "temperature_2m_min",
            "temperature_2m_max", "precipitation_sum", "is_rainy", "weather_source"]
    clean = df[cols]
    clean.to_csv(DATA_PROC / "sales_clean.csv", index=False)

    # order-level and daily tables
    orders = (clean.groupby("order_id").agg(
        timestamp=("timestamp", "first"), date=("date", "first"), hour=("hour", "first"),
        weekday=("weekday", "first"), daypart=("daypart", "first"), channel=("channel", "first"),
        payment_method=("payment_method", "first"), n_distinct_items=("product", "nunique"),
        units=("quantity", "sum"), order_total=("line_total", "sum")).reset_index())
    orders.to_csv(DATA_PROC / "orders_clean.csv", index=False)
    daily = (clean.groupby("date").agg(orders=("order_id", "nunique"), units=("quantity", "sum"),
                                       revenue=("line_total", "sum"),
                                       temp=("temperature_2m_mean", "first"),
                                       rain=("precipitation_sum", "first"),
                                       is_holiday=("is_holiday", "first"),
                                       weekday=("weekday", "first")).reset_index())
    daily.to_csv(DATA_PROC / "daily_demand.csv", index=False)

    # ---------------------------------------------------------- outputs: tables
    audit_after = audit(clean.drop(columns=["price_was_fixed"]), "clean")
    save_table(pd.concat([audit_before, audit_after]), "data_quality_audit")
    log_df = pd.DataFrame(LOG)
    save_table(log_df, "cleaning_log")
    summary = {
        "raw_rows": n0, "clean_rows": len(clean), "orders": int(clean["order_id"].nunique()),
        "products": int(clean["product"].nunique()), "date_min": str(clean["date"].min().date()),
        "date_max": str(clean["date"].max().date()), "days": int(clean["date"].nunique()),
        "rows_removed_pct": round(100 * (1 - len(clean) / n0), 2),
        "revenue_total_cop": float(clean["line_total"].sum()),
        "weather_source": str(clean["weather_source"].iloc[0]),
        "price_fixed_lines": int(clean["price_was_fixed"].sum()),
        "max_plausible_quantity": q_hi_ok, "min_suspicious_quantity": q_lo_bad,
    }
    (TAB_DIR / "dataset_summary.json").write_text(json.dumps(summary, indent=2))
    print("== Summary:", json.dumps(summary, indent=2))

    # ---------------------------------------------------------- figure: before / after
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.5))
    pct_b = before.isna().mean() * 100
    pct_a = clean.drop(columns=["price_was_fixed"]).isna().mean() * 100
    cols_show = ["timestamp", "product", "quantity", "unit_price", "payment_method", "employee_id", "table_no"]
    y = np.arange(len(cols_show))
    ax[0].barh(y - 0.2, [pct_b.get(c, 0) for c in cols_show], 0.4, label="Raw", color=PALETTE[1])
    ax[0].barh(y + 0.2, [pct_a.get(c, 0) for c in cols_show], 0.4, label="Clean", color=PALETTE[2], hatch="//")
    ax[0].set_yticks(y, cols_show); ax[0].invert_yaxis()
    ax[0].set_xlabel("Missing values (%)"); ax[0].set_title("(a) Nulls per column"); ax[0].legend(loc="upper right")
    ax[0].grid(axis="y", visible=False)

    pr = price_before.copy()
    r_raw = (pr["unit_price"] / pr["ref_price"]).replace([np.inf], np.nan).dropna()
    r_raw = r_raw[r_raw > 0]
    bins = np.linspace(-1.2, 2.2, 60)
    ax[1].hist(np.log10(r_raw), bins=bins, color=PALETTE[1], alpha=.9, label="Raw")
    ax[1].hist(np.zeros(1) + 0, bins=bins, color=PALETTE[2], alpha=0)       # keep axis consistent
    ax[1].axvspan(np.log10(0.5), np.log10(2), color=PALETTE[2], alpha=.18, label="Accepted band")
    ax[1].set_yscale("log"); ax[1].set_xlabel("log$_{10}$(price / product-month median)")
    ax[1].set_ylabel("Lines (log)"); ax[1].set_title("(b) Price outliers (raw)")
    ax[1].text(0, 3, "accepted\nband", ha="center", va="bottom", fontsize=6.5, color=PALETTE[2])
    ax[1].text(1.5, 2e3, "×10 and ×100\ntypos", ha="center", fontsize=6.5, color=PALETTE[0])
    ax[1].set_ylim(0.7, 3e5)

    qb = pd.to_numeric(before["quantity"], errors="coerce").dropna()
    bins_q = [-1000, 0, 1, 2, 3, 4, 5, 10, 1000]
    labs = ["≤0", "1", "2", "3", "4", "5", "6–10", ">10"]
    cb = pd.cut(qb, bins=[-1e9, -0.5, 0.5, 1.5, 2.5, 3.5, 4.5, 10.5, 1e9], labels=["<0", "0", "1", "2", "3", "4", "5–10", ">10"]).value_counts().sort_index()
    ca = pd.cut(clean["quantity"], bins=[-1e9, -0.5, 0.5, 1.5, 2.5, 3.5, 4.5, 10.5, 1e9], labels=["<0", "0", "1", "2", "3", "4", "5–10", ">10"]).value_counts().sort_index()
    x = np.arange(len(cb))
    ax[2].bar(x - 0.2, cb.values, 0.4, color=PALETTE[1], label="Raw")
    ax[2].bar(x + 0.2, ca.values, 0.4, color=PALETTE[2], hatch="//", label="Clean")
    ax[2].set_xticks(x, cb.index); ax[2].set_yscale("log"); ax[2].set_xlabel("Quantity per line")
    ax[2].set_ylabel("Lines (log)"); ax[2].set_title("(c) Quantity"); ax[2].legend(loc="upper right", fontsize=6)
    savefig(fig, "fig_cleaning")


if __name__ == "__main__":
    main()
