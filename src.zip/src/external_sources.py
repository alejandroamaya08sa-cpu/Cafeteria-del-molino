"""External data sources for the demand analysis.

1. Weather for Tunja  -> Open-Meteo Historical Weather API (free, no API key).
2. Colombian public holidays -> `holidays` package (offline calendar rules).

Weather strategy (graceful degradation, always logged in ``docs/external_sources_log.txt``):
    live API  ->  previously cached live file  ->  simulated fallback file.
The ``source`` column of ``data/external/weather_tunja.csv`` always says which one was used,
so the report can state the provenance of every external feature honestly.

Usage:  python src/external_sources.py
"""
from __future__ import annotations

import datetime as dt
import shutil

import pandas as pd
import requests

from config import (DATA_EXT, DOCS_DIR, HOLIDAYS_FILE, LAT, LON, RAW_SALES_FILE,
                    TIMEZONE, WEATHER_FILE)

API_URL = "https://archive-api.open-meteo.com/v1/archive"
DAILY_VARS = ["temperature_2m_mean", "temperature_2m_min", "temperature_2m_max", "precipitation_sum"]
LOG_FILE = DOCS_DIR / "external_sources_log.txt"


def log(msg: str) -> None:
    line = f"[{dt.datetime.now().isoformat(timespec='seconds')}] {msg}"
    print(line)
    with open(LOG_FILE, "a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def date_range_from_sales() -> tuple[str, str]:
    """Derive the needed date window from the raw sales file (tolerates mixed formats)."""
    s = pd.read_csv(RAW_SALES_FILE, usecols=["fecha_hora"])["fecha_hora"].dropna()
    iso = pd.to_datetime(s, format="%Y-%m-%d %H:%M:%S", errors="coerce")
    alt = pd.to_datetime(s[iso.isna()], format="%d/%m/%Y %H:%M", errors="coerce")
    d = pd.concat([iso.dropna(), alt.dropna()])
    # discard obviously wrong timestamps by using robust quantiles of the dates
    return (d.quantile(0.0005).strftime("%Y-%m-%d"), d.quantile(0.9995).strftime("%Y-%m-%d"))


def fetch_weather(start: str, end: str, timeout: int = 20) -> pd.DataFrame:
    """Consume the Open-Meteo archive API (JSON) and return a tidy daily frame."""
    params = {"latitude": LAT, "longitude": LON, "start_date": start, "end_date": end,
              "daily": ",".join(DAILY_VARS), "timezone": TIMEZONE}
    r = requests.get(API_URL, params=params, timeout=timeout)
    r.raise_for_status()
    daily = r.json()["daily"]
    df = pd.DataFrame(daily).rename(columns={"time": "date"})
    df["source"] = "open-meteo"
    return df


def build_weather() -> None:
    start, end = date_range_from_sales()
    log(f"Weather window required by sales data: {start} -> {end}")
    try:
        df = fetch_weather(start, end)
        df.to_csv(WEATHER_FILE, index=False)
        log(f"OK  live Open-Meteo API: {len(df)} daily rows saved to {WEATHER_FILE.name}")
        return
    except Exception as exc:  # network blocked, API down, schema change...
        log(f"WARN live Open-Meteo request failed ({type(exc).__name__}: {str(exc)[:120]})")
    if WEATHER_FILE.exists() and "open-meteo" in WEATHER_FILE.read_text()[:2000000]:
        log("Using previously cached live weather file.")
        return
    fallback = DATA_EXT / "weather_tunja_simulated.csv"
    if fallback.exists():
        shutil.copy(fallback, WEATHER_FILE)
        log(f"FALLBACK simulated weather copied to {WEATHER_FILE.name} (source='simulated'). "
            "Re-run this script with Internet access to replace it with real observations.")
    else:
        raise FileNotFoundError("No live API and no simulated fallback available.")


def build_holidays() -> None:
    import holidays as hol
    years = range(2025, 2027)
    co = hol.country_holidays("CO", years=years)
    df = pd.DataFrame(sorted(co.items()), columns=["date", "holiday_name"])
    df["date"] = pd.to_datetime(df["date"]).dt.strftime("%Y-%m-%d")
    df["source"] = "python-holidays"
    df.to_csv(HOLIDAYS_FILE, index=False)
    log(f"OK  Colombian holidays {min(years)}-{max(years)}: {len(df)} dates saved to {HOLIDAYS_FILE.name}")


if __name__ == "__main__":
    build_weather()
    build_holidays()
