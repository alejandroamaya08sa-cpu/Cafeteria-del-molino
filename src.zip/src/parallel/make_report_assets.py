"""Turn benchmark CSV/JSON results into LaTeX assets for the IEEE report.

Writes reports/report_parallel/results_table.tex   (speedup / efficiency table)
       reports/report_parallel/results_macros.tex  (numbers + \\multicoretrue/false switch)

Run automatically at the end of benchmark.py; can also be run alone:
    python src/parallel/make_report_assets.py
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from config import ROOT, TAB_DIR  # noqa: E402

OUT = ROOT / "reports" / "report_parallel"


def build() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(TAB_DIR / "parallel_benchmark.csv")
    proj = pd.read_csv(TAB_DIR / "parallel_amdahl_projection.csv")
    env = json.loads((TAB_DIR / "parallel_env.json").read_text())
    base = df[df.method == "serial"].set_index("task")["t_median_s"]

    # ------------------------------------------------ table
    cols = [1, 2, 4, 8, 16]
    L = [r"\begin{tabular}{@{}llr" + "r" * len(cols) + r"@{}}", r"\toprule",
         r"\textbf{Task} & \textbf{Method} & \textbf{$T_s$ (s)} & " + " & ".join(f"$p{{=}}{c}$" for c in cols) + r"\\", r"\midrule"]
    for task in "ABC":
        first = True
        for m in ["processes", "threads"]:
            d = df[(df.task == task) & (df.method == m)].set_index("p")
            if d.empty:
                continue
            cells = [f"{d.loc[c, 'speedup']:.2f} ({d.loc[c, 'efficiency'] * 100:.0f}\\%)" if c in d.index else "--" for c in cols]
            L.append(f"{task if first else ''} & {m} & {(f'{base[task]:.2f}' if first else '')} & " + " & ".join(cells) + r"\\")
            first = False
        L.append(r"\addlinespace[1pt]")
    L += [r"\bottomrule", r"\end{tabular}"]
    (OUT / "results_table.tex").write_text("\n".join(L))

    # ------------------------------------------------ macros
    def S(task, method, p):
        r = df[(df.task == task) & (df.method == method) & (df.p == p)]
        return float(r["speedup"].iloc[0]) if len(r) else float("nan")

    def E(task, method, p):
        r = df[(df.task == task) & (df.method == method) & (df.p == p)]
        return float(r["efficiency"].iloc[0]) if len(r) else float("nan")

    def best(task):
        d = df[(df.task == task) & (df.method == "processes")]
        r = d.loc[d["speedup"].idxmax()]
        return float(r["speedup"]), int(r["p"]), float(r["efficiency"])

    cores = int(env["usable_cores"])
    bA, pA, eA = best("A"); bB, pB, eB = best("B")
    fB = float(proj[proj.task == "B"]["serial_fraction_f"].iloc[0]); fA = float(proj[proj.task == "A"]["serial_fraction_f"].iloc[0])
    amd = lambda task, p: float(proj[(proj.task == task) & (proj.p == p)]["amdahl_speedup"].iloc[0])
    M = {
        "usableCores": cores, "osCores": int(env["os_cpu_count"]), "nBoot": int(env["replicates"]),
        "nOrders": f"{int(env['mapreduce_orders']):,}".replace(",", "{,}"), "nMonths": int(env["months"]),
        "nReps": int(env["repetitions"]),
        "TsA": f"{base['A']:.2f}", "TsB": f"{base['B']:.2f}", "TsC": f"{base['C']:.2f}",
        "bestSA": f"{bA:.2f}", "bestPA": pA, "bestEA": f"{eA*100:.0f}",
        "bestSB": f"{bB:.2f}", "bestPB": pB, "bestEB": f"{eB*100:.0f}",
        "SAtwo": f"{S('A','processes',2):.2f}", "SAfour": f"{S('A','processes',4):.2f}", "SAeight": f"{S('A','processes',8):.2f}",
        "SBfour": f"{S('B','processes',4):.2f}", "SBeight": f"{S('B','processes',8):.2f}",
        "SAthrFour": f"{S('A','threads',4):.2f}", "SBthrFour": f"{S('B','threads',4):.2f}",
        "SCfour": f"{S('C','threads',4):.2f}", "SCeight": f"{S('C','threads',8):.2f}", "SCsixteen": f"{S('C','threads',16):.2f}",
        "ECeight": f"{E('C','threads',8)*100:.0f}", "ECsixteen": f"{E('C','threads',16)*100:.0f}",
        "fA": f"{fA*100:.1f}", "fB": f"{fB*100:.1f}",
        "AmdBeight": f"{amd('B', 8):.1f}", "AmdBsixteen": f"{amd('B', 16):.1f}", "AmdBmax": f"{1/fB:.0f}" if fB > 0 else "inf",
        "AmdAeight": f"{amd('A', 8):.1f}",
    }
    lines = [f"\\newcommand{{\\{k}}}{{{v}}}" for k, v in M.items()]
    lines.append("\\multicoretrue" if cores >= 4 else "\\multicorefalse")
    (OUT / "results_macros.tex").write_text("\n".join(lines) + "\n")
    print("Wrote", OUT / "results_table.tex", "and", OUT / "results_macros.tex", "| multicore =", cores >= 4)


if __name__ == "__main__":
    build()
