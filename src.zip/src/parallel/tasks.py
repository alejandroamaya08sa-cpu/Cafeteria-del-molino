"""Parallelisable workloads of the Cafetería del Molino analytics pipeline.

Three workloads with different parallel profiles (used by benchmark.py):

A. ``bootstrap``  – CPU-bound, embarrassingly parallel (Monte-Carlo): bootstrap confidence
   intervals for the lift of the association rules (FP-Growth on each resample).
B. ``mapreduce``  – CPU-bound, data-parallel map-reduce: item and pair co-occurrence counts over
   a (replicated) order table; map = count a chunk, reduce = sum the partial counts.
C. ``fetch``      – I/O-bound: one HTTP request per month (weather API). The latency is SIMULATED
   with ``time.sleep`` because the real API is not reachable from every environment.

Design notes
* Workers use the ``fork`` start method and read the big arrays from module globals, so tasks
  are described by tiny messages (a seed, an index range) instead of pickled data.
* Every task is deterministic (per-replicate seeds), so serial and parallel results must be
  identical – this is asserted in benchmark.py.
"""
from __future__ import annotations

import time
from itertools import combinations

import numpy as np
import pandas as pd
from mlxtend.frequent_patterns import fpgrowth

MIN_SUPPORT = 0.01

# ------------------------------------------------------------------ shared state (set by init_*)
_B_VALUES: np.ndarray | None = None
_COLS: list[str] | None = None
_PAIRS: list[tuple[str, str]] | None = None
_MASKS: np.ndarray | None = None
_N_ITEMS = 0
_PAIR_IDX: list[tuple[int, int, int]] = []
_LATENCY = 0.15


# ================================================================== A. bootstrap of rule lifts
def init_bootstrap(B: pd.DataFrame, pairs: list[tuple[str, str]]) -> None:
    global _B_VALUES, _COLS, _PAIRS
    _B_VALUES, _COLS, _PAIRS = B.values, list(B.columns), pairs


def bootstrap_replicate(seed: int) -> np.ndarray:
    """One bootstrap replicate: resample orders, mine frequent itemsets, return lift per pair."""
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(_B_VALUES), len(_B_VALUES))
    fi = fpgrowth(pd.DataFrame(_B_VALUES[idx], columns=_COLS), min_support=MIN_SUPPORT, use_colnames=True)
    supp = {frozenset(s): v for s, v in zip(fi["itemsets"], fi["support"])}
    out = np.full(len(_PAIRS), np.nan)
    for k, (a, c) in enumerate(_PAIRS):
        sac, sa, sc = supp.get(frozenset((a, c))), supp.get(frozenset((a,))), supp.get(frozenset((c,)))
        if sac and sa and sc:
            out[k] = sac / (sa * sc)
    return out


def bootstrap_serial(seeds: list[int]) -> np.ndarray:
    return np.vstack([bootstrap_replicate(s) for s in seeds])


# ================================================================== B. map-reduce co-occurrence
def init_mapreduce(basket_values: np.ndarray, replicate: int) -> int:
    """Encode every order as a bit mask (one bit per product) and tile it ``replicate`` times
    to emulate the growth of the incremental database. Returns the number of orders."""
    global _MASKS, _N_ITEMS, _PAIR_IDX
    _N_ITEMS = basket_values.shape[1]
    base = (basket_values.astype(np.int64) * (1 << np.arange(_N_ITEMS, dtype=np.int64))).sum(axis=1)
    _MASKS = np.tile(base, replicate)
    _PAIR_IDX = [(i, j, (1 << i) | (1 << j)) for i, j in combinations(range(_N_ITEMS), 2)]
    return len(_MASKS)


def count_chunk(bounds: tuple[int, int]) -> tuple[np.ndarray, np.ndarray]:
    """MAP: item counts and pair counts of one chunk of orders."""
    m = _MASKS[bounds[0]:bounds[1]]
    items = np.array([int(((m >> i) & 1).sum()) for i in range(_N_ITEMS)], dtype=np.int64)
    pairs = np.array([int(((m & pm) == pm).sum()) for _, _, pm in _PAIR_IDX], dtype=np.int64)
    return items, pairs


def reduce_counts(parts: list[tuple[np.ndarray, np.ndarray]]) -> tuple[np.ndarray, np.ndarray]:
    """REDUCE: element-wise sum of partial counts."""
    return sum(p[0] for p in parts), sum(p[1] for p in parts)


def make_chunks(n: int, n_chunks: int) -> list[tuple[int, int]]:
    edges = np.linspace(0, n, n_chunks + 1, dtype=np.int64)
    return [(int(a), int(b)) for a, b in zip(edges[:-1], edges[1:])]


def lifts_from_counts(items: np.ndarray, pairs: np.ndarray, n: int) -> np.ndarray:
    si, sp = items / n, pairs / n
    return np.array([sp[k] / (si[i] * si[j]) if sp[k] > 0 else np.nan for k, (i, j, _) in enumerate(_PAIR_IDX)])


# ================================================================== C. I/O-bound fetches
def init_fetch(latency: float) -> None:
    global _LATENCY
    _LATENCY = latency


def fetch_month(month_index: int) -> tuple[int, float]:
    """Stand-in for one Open-Meteo request (simulated network latency)."""
    time.sleep(_LATENCY)
    return month_index, 13.0 + 0.5 * np.sin(month_index)
