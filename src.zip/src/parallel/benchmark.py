"""Parallel / distributed performance benchmark (speedup, efficiency, Amdahl).

Usage:  python src/parallel/benchmark.py            # full run (≈ 5-8 min on one core)
        python src/parallel/benchmark.py --quick    # smoke test (≈ 30 s)

Outputs
  reports/tables/parallel_benchmark.csv        raw medians per task / method / p
  reports/tables/parallel_amdahl_projection.csv   model projection (NOT a measurement)
  reports/tables/parallel_env.json             hardware actually available to the run
  reports/tables/rules_bootstrap_ci.csv        by-product: 95 % bootstrap CIs of rule lifts
  reports/figures/fig_par_scaling.png          speedup and efficiency figure
  reports/report_parallel/results_table.tex + results_macros.tex   consumed by the IEEE report

IMPORTANT: speedup of CPU-bound code cannot exceed the number of physical cores of the machine
that runs this script. The environment is recorded in parallel_env.json and printed in the
report; run the script on your own multi-core machine to obtain the speedups to be reported.
"""
from __future__ import annotations

import argparse
import json
import multiprocessing as mp
import os
import platform
import statistics as st
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # src/ (config, mining_utils, rules_mining)
import tasks as T                                               # noqa: E402
from config import DATA_PROC, ROOT, TAB_DIR                     # noqa: E402
from mining_utils import PALETTE, savefig, set_style, save_table  # noqa: E402
from rules_mining import basket_matrix                          # noqa: E402

CTX = mp.get_context("fork")
P_LIST = [1, 2, 4, 8]
TASK_LABEL = {"A": "A. Bootstrap of rule lifts (CPU-bound)",
              "B": "B. Map-reduce pair counts (CPU-bound)",
              "C": "C. Monthly API fetches (I/O-bound, simulated latency)"}


def timed(fn, reps: int):
    times, res = [], None
    for _ in range(reps):
        t0 = time.perf_counter(); res = fn(); times.append(time.perf_counter() - t0)
    return times, res


# ------------------------------------------------------------------------- task runners
def run_a(seeds, method, p):
    if method == "serial":
        return T.bootstrap_serial(seeds), 0.0
    chunk = max(1, len(seeds) // (p * 4))
    if method == "processes":
        with CTX.Pool(p) as pool:
            t0 = time.perf_counter(); r = pool.map(T.bootstrap_replicate, seeds, chunksize=chunk)
            return np.vstack(r), time.perf_counter() - t0
    with ThreadPoolExecutor(p) as ex:
        t0 = time.perf_counter(); r = list(ex.map(T.bootstrap_replicate, seeds))
        return np.vstack(r), time.perf_counter() - t0


def run_b(n, method, p):
    chunks = T.make_chunks(n, 32)               # same chunking for every method (fair baseline)
    if method == "serial":
        return T.reduce_counts([T.count_chunk(c) for c in chunks]), 0.0
    if method == "processes":
        with CTX.Pool(p) as pool:
            t0 = time.perf_counter(); parts = pool.map(T.count_chunk, chunks, chunksize=1)
            t_map = time.perf_counter() - t0
    else:
        with ThreadPoolExecutor(p) as ex:
            t0 = time.perf_counter(); parts = list(ex.map(T.count_chunk, chunks))
            t_map = time.perf_counter() - t0
    return T.reduce_counts(parts), t_map


def run_c(months, method, p):
    if method == "serial":
        return [T.fetch_month(m) for m in range(months)], 0.0
    with ThreadPoolExecutor(p) as ex:
        t0 = time.perf_counter(); r = list(ex.map(T.fetch_month, range(months)))
        return r, time.perf_counter() - t0


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--reps", type=int, default=3)
    a = ap.parse_args()
    n_boot, rep_factor, months, reps = (24, 20, 12, 2) if a.quick else (120, 100, 36, a.reps)
    set_style()

    env = {"os_cpu_count": os.cpu_count(), "usable_cores": len(os.sched_getaffinity(0)),
           "platform": platform.platform(), "python": platform.python_version(),
           "start_method": "fork", "replicates": n_boot, "mapreduce_replication": rep_factor,
           "months": months, "simulated_latency_s": 0.15, "repetitions": reps}
    print("Environment:", json.dumps(env))

    # ---- data
    S = pd.read_csv(DATA_PROC / "sales_clean.csv")
    B = basket_matrix(S)
    top = pd.read_csv(TAB_DIR / "rules_top15_by_lift.csv").head(10)
    pairs = list(zip(top["antecedent"], top["consequent"]))
    T.init_bootstrap(B, pairs)
    n_orders = T.init_mapreduce(B.values, rep_factor)
    T.init_fetch(0.15)
    seeds = list(range(1000, 1000 + n_boot))
    env["mapreduce_orders"] = int(n_orders)

    rows, fr_serial = [], {}
    plan = {"A": (lambda m, p: run_a(seeds, m, p), ["serial", "processes", "threads"]),
            "B": (lambda m, p: run_b(n_orders, m, p), ["serial", "processes", "threads"]),
            "C": (lambda m, p: run_c(months, m, p), ["serial", "threads"])}
    ref_result, last_boot = {}, None
    for task, (fn, methods) in plan.items():
        print(f"\n== Task {TASK_LABEL[task]}")
        for method in methods:
            plist = [1] if method == "serial" else (P_LIST + ([16] if task == "C" else []))
            if task in ("A", "B") and method == "threads":
                plist = [1, 4]                              # enough to show the GIL effect
            for p in plist:
                if task == "A" and method == "processes" and p == 8 and a.quick:
                    continue
                out = {}
                def call():
                    r, t_map = fn(method, p); out.setdefault("tm", []).append(t_map); return r
                times, res = timed(call, reps)
                med = st.median(times)
                f_ser = float(np.mean([(med - tm) / med for tm in out["tm"]])) if method != "serial" else np.nan
                if method == "serial":
                    ref_result[task] = res
                else:                                       # correctness: parallel == serial
                    if task == "A":
                        assert np.allclose(res, ref_result["A"], equal_nan=True), "bootstrap mismatch"
                        if method == "processes": last_boot = res
                    elif task == "B":
                        assert all(np.array_equal(x, y) for x, y in zip(res, ref_result["B"])), "counts mismatch"
                    else:
                        assert res == ref_result["C"], "fetch mismatch"
                rows.append({"task": task, "method": method, "p": p, "t_median_s": med,
                             "t_min_s": min(times), "t_max_s": max(times), "reps": reps,
                             "overhead_fraction_p": f_ser})
                print(f"  {method:9s} p={p:<2d} median={med:7.3f}s  [{min(times):.3f}, {max(times):.3f}]")

    df = pd.DataFrame(rows)
    base = df[df.method == "serial"].set_index("task")["t_median_s"]
    df["speedup"] = df.apply(lambda r: base[r.task] / r.t_median_s, axis=1)
    df["efficiency"] = df["speedup"] / df["p"]
    df["karp_flatt"] = df.apply(lambda r: ((1 / r.speedup) - (1 / r.p)) / (1 - 1 / r.p) if r.p > 1 else np.nan, axis=1)
    save_table(df.round(4), "parallel_benchmark")

    # ---- Amdahl projection (MODEL): serial fraction measured in the p=1 process run
    proj = []
    for task in ("A", "B"):
        f = float(df[(df.task == task) & (df.method == "processes") & (df.p == 1)]["overhead_fraction_p"].iloc[0])
        f = max(f, 0.0)
        for p in [1, 2, 4, 8, 16, 32]:
            s = 1 / (f + (1 - f) / p)
            proj.append({"task": task, "serial_fraction_f": round(f, 4), "p": p, "amdahl_speedup": round(s, 3),
                         "amdahl_efficiency": round(s / p, 3)})
    proj = pd.DataFrame(proj); save_table(proj, "parallel_amdahl_projection")

    # ---- bootstrap CI (by-product of task A)
    point = top.set_index(["antecedent", "consequent"])["lift"]
    ci = pd.DataFrame({"rule": [f"{x} → {y}" for x, y in pairs], "lift_full_data": [point[(x, y)] for x, y in pairs],
                       "ci95_low": np.nanpercentile(last_boot, 2.5, axis=0), "ci95_high": np.nanpercentile(last_boot, 97.5, axis=0),
                       "n_replicates": n_boot})
    save_table(ci.round(3), "rules_bootstrap_ci")
    env["bootstrap_ci_example"] = ci.iloc[0].to_dict()
    (TAB_DIR / "parallel_env.json").write_text(json.dumps(env, indent=2, default=str))

    # ---- figure: speedup (top) and efficiency (bottom)
    cores = env["usable_cores"]
    fig, ax = plt.subplots(2, 3, figsize=(7.2, 4.4), sharex="col")
    style = {"processes": (PALETTE[0], "o", "-"), "threads": (PALETTE[2], "s", "--")}
    for j, task in enumerate("ABC"):
        d = df[df.task == task]
        pmax = d.p.max()
        ps = np.array([1, 2, 4, 8, 16])
        ax[0, j].plot(ps, ps, color="gray", ls=":", lw=1, label="ideal")
        ax[1, j].axhline(1, color="gray", ls=":", lw=1)
        for m, (c, mk, ls) in style.items():
            dm = d[d.method == m].sort_values("p")
            if len(dm):
                ax[0, j].plot(dm.p, dm.speedup, color=c, marker=mk, ls=ls, label=m)
                ax[1, j].plot(dm.p, dm.efficiency, color=c, marker=mk, ls=ls)
        if task in ("A", "B"):
            pj = proj[proj.task == task]
            ax[0, j].plot(pj.p, pj.amdahl_speedup, color=PALETTE[3], ls="-.", lw=1, label="Amdahl (model)")
        ax[0, j].axvline(cores, color="k", lw=.7, alpha=.5)
        ax[1, j].axvline(cores, color="k", lw=.7, alpha=.5)
        ax[0, j].set_title(TASK_LABEL[task].split(" (")[0], fontsize=7)
        ax[0, j].set_xscale("log", base=2); ax[1, j].set_xscale("log", base=2)
        ax[0, j].set_yscale("log", base=2)
        ax[1, j].set_xlabel("workers $p$"); ax[1, j].set_xticks(ps, [str(x) for x in ps])
        ax[0, j].set_ylim(0.4, 20)
    ax[0, 0].set_ylabel("Speedup $S_p$"); ax[1, 0].set_ylabel("Efficiency $E_p=S_p/p$")
    ax[0, 0].legend(fontsize=5.5, loc="upper left")
    ax[0, 2].text(0.98, 0.04, f"vertical line = usable cores ({cores})", transform=ax[0, 2].transAxes, ha="right", fontsize=5.5)
    savefig(fig, "fig_par_scaling")

    import make_report_assets
    make_report_assets.build()


if __name__ == "__main__":
    main()
