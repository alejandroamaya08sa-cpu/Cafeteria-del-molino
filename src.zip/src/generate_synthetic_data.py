"""Generate a SYNTHETIC raw sales export that emulates the Cafetería del Molino database.

IMPORTANT
---------
The real historical database (sales, employees, money, inventory) was not available when
this module was written. This script produces a stand-in dataset with the same *shape*
(one row per order line) and with realistic data-quality problems (nulls, duplicates,
inconsistent product names, typos, outliers, mixed date formats) so that the whole
cleaning / EDA / mining pipeline can be developed and tested.

To use the real data: export it to ``data/raw/ventas_raw.csv`` (or edit
``config.COLUMN_MAP``) and skip this script. Nothing else in the pipeline depends on it.

Usage:  python src/generate_synthetic_data.py
"""
from __future__ import annotations

import json
import unicodedata
from collections import Counter

import numpy as np
import pandas as pd

from config import (DATA_EXT, DATA_RAW, RAW_CATALOG_FILE, RAW_SALES_FILE, SEED,
                    WEATHER_FILE)

rng = np.random.default_rng(SEED)

START, END = pd.Timestamp("2025-02-03"), pd.Timestamp("2026-06-30")

# --------------------------------------------------------------------------------------
# Product catalogue: name, category, role, base price (COP, Feb-2025), cost ratio,
# thermal type, base popularity, daypart weights (Morning, Midday, Afternoon, Evening)
# --------------------------------------------------------------------------------------
PRODUCTS = [
    # name,               category,       role,    price, cost, temp,    pop,  M,   D,   A,   E
    ("Tinto",             "Hot drinks",  "drink",  2500, .30, "hot",    1.70, 1.6, .8,  .9,  .6),
    ("Café Americano",    "Hot drinks",  "drink",  4000, .28, "hot",    1.00, 1.4, .9,  1.0, .8),
    ("Capuchino",         "Hot drinks",  "drink",  6500, .27, "hot",    1.30, 1.0, .9,  1.3, 1.0),
    ("Latte",             "Hot drinks",  "drink",  7000, .27, "hot",    .80,  .9,  .9,  1.3, 1.0),
    ("Mocca",             "Hot drinks",  "drink",  7500, .29, "hot",    .70,  .7,  .8,  1.5, 1.2),
    ("Chocolate Caliente", "Hot drinks", "drink",  6000, .30, "hot",    1.10, 1.1, .7,  1.4, 1.2),
    ("Aromática",         "Hot drinks",  "drink",  3000, .20, "hot",    .70,  .6,  .8,  1.2, 1.7),
    ("Limonada Natural",  "Cold drinks", "drink",  5000, .30, "cold",   .90,  .4,  1.8, 1.0, .6),
    ("Jugo Natural",      "Cold drinks", "drink",  6000, .35, "cold",   .90,  .8,  1.7, .8,  .5),
    ("Malteada",          "Cold drinks", "drink",  9500, .33, "cold",   .50,  .1,  .8,  1.8, 1.2),
    ("Frappé de Café",    "Cold drinks", "drink",  9000, .30, "cold",   .45,  .1,  .8,  1.8, 1.2),
    ("Té Frío",           "Cold drinks", "drink",  4500, .22, "cold",   .40,  .2,  1.5, 1.1, .7),
    ("Agua",              "Cold drinks", "drink",  3000, .35, "neutral", .35, .5,  1.3, 1.0, .8),
    ("Gaseosa",           "Cold drinks", "drink",  3500, .55, "cold",   .45,  .2,  1.7, .9,  .7),
    ("Almojábana",        "Bakery",      "food",   2500, .35, "neutral", 1.00, 1.7, .6, .9, .7),
    ("Pan de Bono",       "Bakery",      "food",   2500, .35, "neutral", 1.00, 1.6, .6, 1.0, .8),
    ("Empanada",          "Bakery",      "food",   3000, .40, "neutral", .90,  .8, 1.5, 1.0, .7),
    ("Pastel de Pollo",   "Bakery",      "food",   4500, .42, "neutral", .80,  .7, 1.6, 1.0, .6),
    ("Croissant",         "Bakery",      "food",   5000, .38, "neutral", .60,  1.3, .8, 1.2, .8),
    ("Sándwich Molino",   "Meals",       "food",  12000, .40, "neutral", .90,  .5, 2.2, .8,  .5),
    ("Arepa con Queso",   "Meals",       "food",   7000, .38, "neutral", .60, 1.6, .9, .8,  .6),
    ("Huevos Pericos",    "Meals",       "food",   9500, .36, "neutral", .45, 2.4, .5, .1,  .1),
    ("Desayuno Molino",   "Meals",       "food",  16000, .42, "neutral", .45, 2.6, .5, .1,  .1),
    ("Waffle",            "Meals",       "food",  12500, .33, "neutral", .45,  .5, .8, 1.8, 1.4),
    ("Ensalada de Frutas", "Meals",      "food",   7500, .40, "cold",   .40,  .7, 1.4, 1.0, .5),
    ("Brownie",           "Desserts",    "food",   6000, .33, "neutral", .70,  .3, .9, 1.7, 1.5),
    ("Cheesecake",        "Desserts",    "food",   8500, .36, "neutral", .50,  .2, .9, 1.8, 1.6),
    ("Torta de Chocolate", "Desserts",   "food",   7500, .34, "neutral", .50,  .2, .9, 1.8, 1.6),
    ("Galletas",          "Desserts",    "food",   3500, .30, "neutral", .45,  .6, .9, 1.3, 1.1),
]
PCOLS = ["name", "category", "role", "price0", "cost", "temp", "pop", "M", "D", "A", "E"]
CAT = pd.DataFrame(PRODUCTS, columns=PCOLS)
NAMES = CAT["name"].tolist()
DRINKS = CAT.index[CAT.role == "drink"].tolist()
FOODS = CAT.index[CAT.role == "food"].tolist()

# Companion-food affinity: P(adding food | drink). This planted structure is what the
# association-rule module should be able to rediscover.
AFFINITY = {
    "Tinto": {"Almojábana": .30, "Pan de Bono": .22, "Empanada": .10},
    "Café Americano": {"Croissant": .18, "Almojábana": .14, "Empanada": .10},
    "Capuchino": {"Croissant": .18, "Brownie": .15, "Cheesecake": .09, "Pan de Bono": .08},
    "Latte": {"Croissant": .25, "Torta de Chocolate": .15, "Galletas": .08},
    "Mocca": {"Brownie": .27, "Cheesecake": .20, "Torta de Chocolate": .10},
    "Chocolate Caliente": {"Pan de Bono": .30, "Almojábana": .20, "Arepa con Queso": .15},
    "Aromática": {"Pan de Bono": .20, "Galletas": .15, "Almojábana": .10},
    "Limonada Natural": {"Sándwich Molino": .30, "Pastel de Pollo": .20, "Empanada": .15},
    "Jugo Natural": {"Sándwich Molino": .30, "Ensalada de Frutas": .14, "Arepa con Queso": .10},
    "Malteada": {"Waffle": .30, "Brownie": .15, "Galletas": .10},
    "Frappé de Café": {"Waffle": .22, "Cheesecake": .15, "Brownie": .10},
    "Té Frío": {"Sándwich Molino": .20, "Galletas": .12, "Ensalada de Frutas": .10},
    "Agua": {"Pastel de Pollo": .25, "Empanada": .20, "Sándwich Molino": .20},
    "Gaseosa": {"Pastel de Pollo": .28, "Empanada": .25, "Sándwich Molino": .20},
}
# Food-first items that pull a drink with them
FOOD_PULLS_DRINK = {
    "Huevos Pericos": {"Tinto": .45, "Chocolate Caliente": .30, "Jugo Natural": .15},
    "Desayuno Molino": {"Tinto": .35, "Chocolate Caliente": .25, "Jugo Natural": .25},
    "Arepa con Queso": {"Chocolate Caliente": .45, "Tinto": .25},
    "Waffle": {"Malteada": .35, "Frappé de Café": .20, "Capuchino": .15},
    "Sándwich Molino": {"Limonada Natural": .35, "Jugo Natural": .30, "Té Frío": .10},
    "Pastel de Pollo": {"Gaseosa": .30, "Limonada Natural": .20, "Tinto": .15},
}

PRICE_STEPS = [(pd.Timestamp("2025-07-01"), 1.05), (pd.Timestamp("2026-01-01"), 1.07)]
DAYPART_COL = {7: "M", 8: "M", 9: "M", 10: "M", 11: "D", 12: "D", 13: "D", 14: "D",
               15: "A", 16: "A", 17: "A", 18: "E", 19: "E"}


def price_on(day: pd.Timestamp, base: float) -> int:
    f = 1.0
    for d, inc in PRICE_STEPS:
        if day >= d:
            f *= inc
    return int(round(base * f / 100.0) * 100)


# --------------------------------------------------------------------------------------
# 1) Simulated weather for Tunja (used to drive demand; also saved as offline fallback)
# --------------------------------------------------------------------------------------
def simulate_weather(days: pd.DatetimeIndex) -> pd.DataFrame:
    n = len(days)
    doy = days.dayofyear.values
    # Tunja ~2,800 m a.s.l.: mean ≈ 13 °C, mild seasonality; wetter Apr-May and Oct-Nov
    seasonal = 0.7 * np.cos(2 * np.pi * (doy - 190) / 365)
    ar = np.zeros(n)
    for i in range(1, n):
        ar[i] = 0.7 * ar[i - 1] + rng.normal(0, 0.8)
    tmean = 13.2 + seasonal + ar
    wet = 0.30 + 0.22 * (np.cos(2 * np.pi * (doy - 120) / 182.5) > 0.3)
    rain = np.where(rng.random(n) < wet, rng.gamma(1.4, 4.0, n), 0.0)
    tmean = tmean - 0.12 * np.minimum(rain, 12)           # rainy days are cooler
    return pd.DataFrame({
        "date": days.strftime("%Y-%m-%d"),
        "temperature_2m_mean": tmean.round(1),
        "temperature_2m_min": (tmean - rng.uniform(3.0, 4.5, n)).round(1),
        "temperature_2m_max": (tmean + rng.uniform(4.0, 6.5, n)).round(1),
        "precipitation_sum": rain.round(1),
        "source": "simulated",
    })


# --------------------------------------------------------------------------------------
# 2) Simulate clean orders
# --------------------------------------------------------------------------------------
def pick(weights: np.ndarray) -> int:
    p = weights / weights.sum()
    return int(rng.choice(len(p), p=p))


def build_orders(weather: pd.DataFrame) -> pd.DataFrame:
    import holidays as hol
    co = hol.country_holidays("CO", years=[2025, 2026])
    days = pd.date_range(START, END, freq="D")
    n_days = len(days)
    wd_factor = np.array([.85, .95, 1.0, 1.05, 1.2, 1.3, .95])
    m_factor = {1: .70, 2: .90, 3: 1.05, 4: 1.00, 5: 1.05, 6: .85, 7: .75, 8: 1.00,
                9: 1.05, 10: 1.05, 11: 1.00, 12: .70}
    hour_wk = np.array([.07, .12, .10, .07, .06, .08, .07, .05, .08, .10, .10, .07, .03])
    hour_we = np.array([.02, .05, .08, .10, .10, .10, .08, .07, .09, .10, .10, .08, .03])
    hours = np.arange(7, 20)
    wx = weather.set_index("date")

    rows, order_no, line_no = [], 0, 0
    for i, day in enumerate(days):
        w = wx.loc[day.strftime("%Y-%m-%d")]
        temp, rain = float(w.temperature_2m_mean), float(w.precipitation_sum)
        lam = (52 * wd_factor[day.dayofweek] * m_factor[day.month]
               * (1 + 0.14 * i / n_days)
               * (1 + 0.04 * min(rain / 8, 2))
               * (0.85 if day in co else 1.0)
               * rng.lognormal(0, 0.07))
        n_orders = rng.poisson(lam)
        hp = hour_we if day.dayofweek >= 5 else hour_wk
        order_hours = rng.choice(hours, size=n_orders, p=hp / hp.sum())
        order_hours.sort()
        # Channel: waiter-only until the QR pilot (2026-03-01), then QR share ramps up
        qr_share = 0.0
        if day >= pd.Timestamp("2026-03-01"):
            qr_share = min(0.30, 0.04 + 0.26 * (day - pd.Timestamp("2026-03-01")).days / 120)
        hot_mult = np.exp(-0.06 * (temp - 13.2)) * (1.15 if rain > 2 else 1.0)
        cold_mult = 1 / hot_mult

        for h in order_hours:
            order_no += 1
            dp = DAYPART_COL[int(h)]
            ts = day + pd.Timedelta(hours=int(h), minutes=int(rng.integers(0, 60)),
                                    seconds=int(rng.integers(0, 60)))
            channel = "QR" if rng.random() < qr_share else "Mesero"
            persons = 1 + int(rng.choice([0, 1, 2, 3, 4], p=[.45, .32, .13, .07, .03]))
            basket: Counter = Counter()
            for _ in range(persons):
                dw = CAT.loc[DRINKS, "pop"].values * CAT.loc[DRINKS, dp].values
                tm = CAT.loc[DRINKS, "temp"].map({"hot": hot_mult, "cold": cold_mult,
                                                  "neutral": 1.0}).values
                fw = CAT.loc[FOODS, "pop"].values * CAT.loc[FOODS, dp].values
                if rng.random() < 0.86:                       # drink-first customer
                    d_name = NAMES[DRINKS[pick(dw * tm)]]
                    basket[d_name] += 1
                    for f_name, p in AFFINITY[d_name].items():
                        if rng.random() < p * (1.15 if dp in ("M", "A") else 1.0):
                            basket[f_name] += 1
                            break
                    if rng.random() < 0.05:                   # occasional extra snack
                        basket[NAMES[FOODS[pick(fw)]]] += 1
                else:                                         # food-first customer
                    f_name = NAMES[FOODS[pick(fw)]]
                    basket[f_name] += 1
                    pulls = FOOD_PULLS_DRINK.get(f_name)
                    if pulls and rng.random() < sum(pulls.values()):
                        names, probs = zip(*pulls.items())
                        basket[str(rng.choice(names, p=np.array(probs) / sum(probs)))] += 1
            pay_pool = (["Nequi", "Tarjeta débito", "Daviplata", "Tarjeta crédito"] if channel == "QR"
                        else ["Efectivo", "Nequi", "Tarjeta débito", "Tarjeta crédito", "Daviplata"])
            pay_p = ([.45, .25, .20, .10] if channel == "QR" else [.55, .18, .12, .08, .07])
            pay = str(rng.choice(pay_pool, p=pay_p))
            table = np.nan if rng.random() < 0.12 else int(rng.integers(1, 16))
            if channel == "QR":
                emp = np.nan                                  # structural null: self-service
            else:
                pool = ["EMP-01", "EMP-02", "EMP-03"] if h < 14 else ["EMP-04", "EMP-05", "EMP-06"]
                if rng.random() < 0.15:
                    pool = ["EMP-01", "EMP-02", "EMP-03", "EMP-04", "EMP-05", "EMP-06"]
                emp = str(rng.choice(pool))
            for prod, q in basket.items():
                line_no += 1
                base = float(CAT.loc[CAT.name == prod, "price0"].iloc[0])
                rows.append((line_no, f"P{order_no:06d}", ts, table, channel, emp, prod, q,
                             price_on(day, base), pay))
    df = pd.DataFrame(rows, columns=["id_linea", "id_pedido", "fecha_hora", "mesa", "canal",
                                     "id_empleado", "producto", "cantidad", "precio_unitario",
                                     "metodo_pago"])
    df["mesa"] = df["mesa"].astype("Int64")
    return df


# --------------------------------------------------------------------------------------
# 3) Inject realistic data-quality problems
# --------------------------------------------------------------------------------------
def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn")


KNOWN_TYPOS = {"Capuchino": ["Capuccino", "Cappuccino", "Capucino"], "Pan de Bono": ["Pan de bono", "Pandebono"],
               "Almojábana": ["Almojabana", "Almojábana "], "Limonada Natural": ["Limonada natural", "Limonada"],
               "Sándwich Molino": ["Sandwich Molino", "Sándwich molino"], "Café Americano": ["Cafe Americano", "Americano"],
               "Chocolate Caliente": ["Chocolate caliente", "Chocolate"], "Frappé de Café": ["Frappe de Cafe"],
               "Torta de Chocolate": ["Torta chocolate"], "Aromática": ["Aromatica", "Aromática "]}


def dirty_name(name: str) -> str:
    r = rng.random()
    if r < 0.30 and name in KNOWN_TYPOS:
        return str(rng.choice(KNOWN_TYPOS[name]))
    if r < 0.50:
        return name.lower()
    if r < 0.62:
        return name.upper()
    if r < 0.80:
        return " " + name + " "
    return strip_accents(name)


def inject_dirt(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    df = df.copy()
    n = len(df)
    log: dict = {"clean_rows": int(n)}

    def frac(p: float) -> np.ndarray:
        return rng.random(n) < p

    # Inconsistent product names (~4 %)
    m = frac(0.04)
    df.loc[m, "producto"] = df.loc[m, "producto"].map(dirty_name)
    log["product_name_variants"] = int(m.sum())

    # Prices: typos with extra zeros / zero / drops
    m = frac(0.003)
    df.loc[m, "precio_unitario"] = df.loc[m, "precio_unitario"] * rng.choice([10, 100], m.sum())
    log["price_scaled_x10_x100"] = int(m.sum())
    m = frac(0.002)
    df.loc[m, "precio_unitario"] = 0
    log["price_zero"] = int(m.sum())

    # Quantity: big typos and negatives
    m = frac(0.0015)
    df.loc[m, "cantidad"] = rng.choice([20, 24, 50, 100], m.sum())
    log["quantity_extreme"] = int(m.sum())
    m = frac(0.002)
    df.loc[m, "cantidad"] = -df.loc[m, "cantidad"]
    log["quantity_negative"] = int(m.sum())

    # Timestamps -> strings, 3 % in dd/mm/YYYY HH:MM format; out-of-hours clock errors
    m_oh = frac(0.0015)
    ts = df["fecha_hora"].copy()
    ts.loc[m_oh] = ts.loc[m_oh].apply(lambda t: t.replace(hour=int(rng.choice([2, 3, 4, 23])), minute=int(rng.integers(0, 60))))
    log["timestamp_out_of_hours"] = int(m_oh.sum())
    s = ts.dt.strftime("%Y-%m-%d %H:%M:%S")
    m_fmt = frac(0.03)
    s.loc[m_fmt] = ts.loc[m_fmt].dt.strftime("%d/%m/%Y %H:%M")
    log["timestamp_alt_format"] = int(m_fmt.sum())
    df["fecha_hora"] = s

    # Missing values (random)
    for col, p in [("cantidad", .012), ("precio_unitario", .015), ("metodo_pago", .03),
                   ("producto", .002), ("fecha_hora", .001)]:
        mm = frac(p)
        df[col] = df[col].astype(object)
        df.loc[mm, col] = np.nan
        log[f"missing_{col}"] = int(mm.sum())
    mm = frac(0.02)
    df.loc[mm & (df["canal"] == "Mesero"), "id_empleado"] = np.nan
    log["missing_employee_random"] = int((mm & (df["canal"] == "Mesero")).sum())

    # Exact duplicates (double submissions)
    dup = df.sample(frac=0.008, random_state=SEED)
    df = pd.concat([df, dup]).sort_index(kind="stable").reset_index(drop=True)
    log["exact_duplicates"] = int(len(dup))
    log["raw_rows"] = int(len(df))
    return df, log


def main() -> None:
    days = pd.date_range(START, END, freq="D")
    weather = simulate_weather(days)
    weather.to_csv(DATA_EXT / "weather_tunja_simulated.csv", index=False)
    print(f"Simulated weather: {len(weather)} days")

    clean = build_orders(weather)
    print(f"Simulated clean orders: {clean['id_pedido'].nunique():,} | lines: {len(clean):,}")
    raw, log = inject_dirt(clean)
    raw.to_csv(RAW_SALES_FILE, index=False)
    CAT.rename(columns={"name": "producto", "category": "categoria", "price0": "precio_base_feb2025",
                        "cost": "ratio_costo"})[["producto", "categoria", "precio_base_feb2025", "ratio_costo"]] \
        .to_csv(RAW_CATALOG_FILE, index=False)
    (DATA_RAW / "_simulation_ground_truth.json").write_text(json.dumps(log, indent=2))
    print(json.dumps(log, indent=2))
    print(f"Saved -> {RAW_SALES_FILE}")


if __name__ == "__main__":
    main()
