"""Step 2 – Exploratory Data Analysis (EDA).

Reads  data/processed/*.csv   Writes reports/figures/fig_eda_*.png, reports/tables/eda_*.csv,
reports/tables/eda_stats.json
Usage:  python src/eda.py
"""
from __future__ import annotations

import json

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

from config import DATA_PROC, DAYPART_ORDER, WEEKDAY_ORDER
from mining_utils import PALETTE, save_table, savefig, set_style


def main() -> None:
    set_style()
    S = pd.read_csv(DATA_PROC / "sales_clean.csv", parse_dates=["timestamp", "date"])
    O = pd.read_csv(DATA_PROC / "orders_clean.csv", parse_dates=["timestamp", "date"])
    D = pd.read_csv(DATA_PROC / "daily_demand.csv", parse_dates=["date"])
    out: dict = {}

    # ---------------- descriptive statistics
    desc = O[["n_distinct_items", "units", "order_total"]].describe().T.round(2)
    desc["skew"] = O[["n_distinct_items", "units", "order_total"]].skew().round(2).values
    save_table(desc.reset_index().rename(columns={"index": "variable"}), "eda_order_descriptives")
    out["orders"] = int(len(O)); out["avg_ticket"] = float(O["order_total"].mean())
    out["median_ticket"] = float(O["order_total"].median()); out["avg_items"] = float(O["n_distinct_items"].mean())
    out["avg_orders_per_day"] = float(D["orders"].mean())
    out["order_total_skew"] = float(O["order_total"].skew())
    # outlier share in ticket (Tukey fence, reported not removed: large tickets = real group orders)
    q1, q3 = O["order_total"].quantile([.25, .75]); fence = q3 + 1.5 * (q3 - q1)
    out["ticket_tukey_fence"] = float(fence); out["ticket_outlier_pct"] = float((O["order_total"] > fence).mean() * 100)

    # ---------------- product ranking & Pareto
    prod = (S.groupby(["product", "category"]).agg(units=("quantity", "sum"), revenue=("line_total", "sum"),
                                                   orders=("order_id", "nunique")).reset_index()
            .sort_values("revenue", ascending=False))
    prod["revenue_share"] = prod["revenue"] / prod["revenue"].sum()
    prod["cum_share"] = prod["revenue_share"].cumsum()
    save_table(prod, "eda_product_ranking")
    out["top_product_units"] = prod.sort_values("units", ascending=False).iloc[0]["product"]
    out["top_product_revenue"] = prod.iloc[0]["product"]
    out["n_products_80pct_revenue"] = int((prod["cum_share"] < 0.8).sum() + 1)
    cat = S.groupby("category").agg(units=("quantity", "sum"), revenue=("line_total", "sum")).sort_values("revenue", ascending=False)
    cat["revenue_pct"] = (cat["revenue"] / cat["revenue"].sum() * 100).round(1)
    save_table(cat.reset_index(), "eda_category_summary")

    # ---------------- temporal patterns
    nd = D["date"].nunique()
    days_per_wd = D.groupby("weekday")["date"].nunique()
    hh = O.groupby(["weekday", "hour"]).size().unstack(fill_value=0)
    heat = hh.div(days_per_wd, axis=0)
    heat.index = WEEKDAY_ORDER
    peak = heat.stack().idxmax()
    out["peak_slot"] = f"{peak[0]} {int(peak[1])}:00"; out["peak_slot_orders_per_hour"] = float(heat.stack().max())
    wd = D.groupby("weekday")["orders"].mean(); wd.index = WEEKDAY_ORDER
    out["orders_by_weekday"] = wd.round(1).to_dict()
    dp = O["daypart"].value_counts(normalize=True).reindex(DAYPART_ORDER) * 100
    out["daypart_share_pct"] = dp.round(1).to_dict()
    kw = stats.kruskal(*[g["orders"].values for _, g in D.groupby("weekday")])
    out["kruskal_weekday_orders"] = {"H": float(kw.statistic), "p": float(kw.pvalue)}
    monthly = S.groupby("month").agg(orders=("order_id", "nunique"), revenue=("line_total", "sum")).reset_index()
    ch = S.drop_duplicates("order_id").groupby(["month", "channel"]).size().unstack(fill_value=0)
    ch["qr_share"] = ch.get("QR", 0) / ch.sum(axis=1) * 100
    last = ch.iloc[-1]
    out["qr_share_last_month_pct"] = float(last["qr_share"]); out["qr_first_month"] = str(ch.index[ch["qr_share"] > 0][0])
    # Compare ticket: QR vs waiter after QR launch
    post = O[O["timestamp"] >= "2026-03-01"]
    a, b_ = post[post.channel == "QR"]["order_total"], post[post.channel == "Mesero"]["order_total"]
    mw = stats.mannwhitneyu(a, b_)
    out["ticket_qr_vs_waiter"] = {"qr_mean": float(a.mean()), "waiter_mean": float(b_.mean()), "p": float(mw.pvalue)}

    # ---------------- weather relations (daily level)
    hot = S.groupby("date").apply(lambda g: g.loc[g.is_hot_drink, "quantity"].sum() / g["quantity"].sum(), include_groups=False).rename("hot_share")
    D2 = D.merge(hot.reset_index(), on="date")
    D2["rainy"] = D2["rain"] >= 1
    rho_t, p_t = stats.spearmanr(D2["temp"], D2["hot_share"])
    rho_o, p_o = stats.spearmanr(D2["rain"], D2["orders"])
    out["spearman_temp_hotshare"] = {"rho": float(rho_t), "p": float(p_t)}
    out["spearman_rain_orders"] = {"rho": float(rho_o), "p": float(p_o)}
    mw2 = stats.mannwhitneyu(D2.loc[D2.rainy, "hot_share"], D2.loc[~D2.rainy, "hot_share"])
    out["hotshare_rainy_vs_dry"] = {"rainy": float(D2.loc[D2.rainy, "hot_share"].mean()), "dry": float(D2.loc[~D2.rainy, "hot_share"].mean()), "p": float(mw2.pvalue)}
    out["rainy_days_pct"] = float(D2["rainy"].mean() * 100)
    hol = D2.groupby("is_holiday")["orders"].mean()
    out["orders_holiday_vs_normal"] = {"holiday": float(hol.get(True, np.nan)), "normal": float(hol.get(False, np.nan))}
    # chi-square: channel x daypart after launch
    ct = pd.crosstab(post["channel"], post["daypart"])
    chi = stats.chi2_contingency(ct)
    out["chi2_channel_daypart"] = {"chi2": float(chi[0]), "p": float(chi[1]), "dof": int(chi[2])}
    # payment
    out["payment_share_pct"] = (O["payment_method"].value_counts(normalize=True) * 100).round(1).to_dict()

    # ================= FIGURES =================
    # Fig 1: overview (2 x 2) --------------------------------------------------------------
    fig, ax = plt.subplots(2, 2, figsize=(7.2, 5.4))
    top = prod.sort_values("units", ascending=True).tail(15)
    cmap = {c: PALETTE[i] for i, c in enumerate(sorted(S["category"].unique()))}
    ax[0, 0].barh(top["product"], top["units"], color=top["category"].map(cmap))
    ax[0, 0].set_title("(a) Top-15 products by units sold"); ax[0, 0].set_xlabel("Units")
    ax[0, 0].grid(axis="y", visible=False)
    handles = [plt.Rectangle((0, 0), 1, 1, color=c) for c in cmap.values()]
    ax[0, 0].legend(handles, cmap.keys(), fontsize=6, loc="lower right")

    sns.heatmap(heat[sorted(heat.columns)], cmap="YlOrBr", ax=ax[0, 1], cbar_kws={"label": "orders / hour", "shrink": .8}, linewidths=.3)
    ax[0, 1].set_title("(b) Avg. orders per hour by weekday"); ax[0, 1].set_xlabel("Hour of day"); ax[0, 1].set_ylabel("")
    ax[0, 1].grid(False)

    x = np.arange(len(monthly))
    ax[1, 0].bar(x, monthly["orders"], color=PALETTE[1], label="Orders / month")
    ax[1, 0].set_xticks(x[::2], monthly["month"][::2], rotation=45, ha="right")
    ax[1, 0].set_ylabel("Orders"); ax[1, 0].set_title("(c) Monthly orders and QR adoption")
    a2 = ax[1, 0].twinx(); a2.plot(x, ch["qr_share"].values, color=PALETTE[2], marker="o", ms=3, label="QR share (%)")
    a2.set_ylabel("QR share (%)"); a2.grid(False); a2.spines["right"].set_visible(True)
    h1, l1 = ax[1, 0].get_legend_handles_labels(); h2, l2 = a2.get_legend_handles_labels()
    ax[1, 0].legend(h1 + h2, l1 + l2, loc="upper left", fontsize=6)

    ax[1, 1].hist(O["order_total"] / 1000, bins=60, color=PALETTE[0], alpha=.9)
    ax[1, 1].axvline(O["order_total"].median() / 1000, color=PALETTE[3], ls="--", lw=1, label=f"Median {O['order_total'].median()/1000:.1f}k")
    ax[1, 1].axvline(O["order_total"].mean() / 1000, color=PALETTE[2], ls=":", lw=1.4, label=f"Mean {O['order_total'].mean()/1000:.1f}k")
    ax[1, 1].set_xlabel("Order total (thousand COP)"); ax[1, 1].set_ylabel("Orders"); ax[1, 1].set_title("(d) Ticket distribution (right-skewed)")
    ax[1, 1].legend()
    savefig(fig, "fig_eda_overview")

    # Fig 2: weather & calendar (1 x 3) ---------------------------------------------------
    fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.5))
    ax[0].scatter(D2["temp"], D2["hot_share"] * 100, s=7, alpha=.45, color=PALETTE[1])
    z = np.polyfit(D2["temp"], D2["hot_share"] * 100, 1); xs = np.linspace(D2["temp"].min(), D2["temp"].max(), 50)
    ax[0].plot(xs, np.polyval(z, xs), color=PALETTE[3], lw=1.5)
    ax[0].set_xlabel("Mean temperature (°C)"); ax[0].set_ylabel("Hot-drink share of units (%)")
    ax[0].set_title(f"(a) Temp. vs hot drinks (ρ={rho_t:.2f})")
    sns.boxplot(data=D2, x=D2["rainy"].map({False: "Dry", True: "Rainy"}), y="orders", ax=ax[1], palette=[PALETTE[1], PALETTE[2]], hue=D2["rainy"].map({False: "Dry", True: "Rainy"}), legend=False, width=.5, fliersize=2)
    ax[1].set_xlabel(""); ax[1].set_ylabel("Orders per day"); ax[1].set_title("(b) Orders: dry vs rainy days")
    wdf = D2.assign(day=D2["weekday"].map(dict(enumerate(WEEKDAY_ORDER))))
    sns.boxplot(data=wdf, x="day", y="orders", order=WEEKDAY_ORDER, ax=ax[2], color=PALETTE[1], width=.6, fliersize=2)
    ax[2].set_xlabel(""); ax[2].set_ylabel("Orders per day"); ax[2].set_title("(c) Daily orders by weekday")
    savefig(fig, "fig_eda_weather")

    # Fig 3: correlation matrix of daily variables ---------------------------------------
    num = D2[["orders", "units", "revenue", "temp", "rain", "hot_share"]].copy()
    num["weekend"] = (D2["weekday"] >= 5).astype(int); num["holiday"] = D2["is_holiday"].astype(int)
    corr = num.corr(method="spearman")
    save_table(corr.round(3).reset_index().rename(columns={"index": "variable"}), "eda_spearman_matrix")
    fig, ax = plt.subplots(figsize=(3.5, 3.0))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="BrBG", center=0, vmin=-1, vmax=1, ax=ax, annot_kws={"size": 6}, cbar_kws={"shrink": .75}, linewidths=.3)
    ax.set_title("Spearman correlation (daily level)"); ax.grid(False)
    savefig(fig, "fig_eda_corr")

    # product-category by daypart (used in the report text)
    cd = S.pivot_table(index="category", columns="daypart", values="quantity", aggfunc="sum")[DAYPART_ORDER]
    save_table((cd.div(cd.sum(axis=0), axis=1) * 100).round(1).reset_index(), "eda_category_share_by_daypart")

    json.dump(out, open(DATA_PROC.parents[1] / "reports" / "tables" / "eda_stats.json", "w"), indent=2, default=str)
    print(json.dumps(out, indent=2, default=str))


if __name__ == "__main__":
    main()
